# Make sharp software videos

A focused Fireship-inspired production course for Aadil.

<a id="preface"></a>
## Start here

Learn a small set of skills in order: choose the explanation, write it, record the voice, capture evidence, assemble the pictures, then polish. Start with a 90–150-second developer explainer. Keep your own perspective and humour.

This focused course uses your eight-to-ten-hour weekly schedule and screen-first filming preference. Work through one lesson each week. The reusable playbook comes afterward, when the basic operations feel familiar. Six weeks establishes a practice system; it does not guarantee parity with a professional creator.

Historical facts about Jeff's process are dated and separated from our original recipes. The equipment recommendations are for your needs. His current exact gear, presets and private workflow remain unverified. The resource links teach the relevant operation; there is no requirement to complete an entire certification before making a video.


<a id="contents"></a>
## Contents

- [Week 1: 01 — Study the decisions, then make a small setup](#chapter-01)
- [Week 2: 02 — Write for spoken clarity and plan what the viewer sees](#chapter-02)
- [Week 3: 03 — Record useful pieces and build the voice track first](#chapter-03)
- [Week 4: 04 — Learn seven editing moves and reuse them](#chapter-04)
- [Week 5: 05 — Assemble one complete video and finish it carefully](#chapter-05)
- [Week 6: 06 — Improve by comparison, then use a repeatable cycle](#chapter-06)
- [equipment](#equipment)
- [playbook](#playbook)
- [sample script](#sample-script)
- [sources](#sources)
- [Interactive editing practice](editing-lab.html)


---

<a id="chapter-01"></a>
## 01 — Study the decisions, then make a small setup

**Your result this week:** a short reference analysis, one editor ready to use, and a clean twenty-second recording. Use 8.5 hours total. You already know programming; you do not need editing experience.

<a id="chapter-01-section-1"></a>
### What we actually know about the reference

Jeff's [2020 production walkthrough](https://www.youtube.com/watch?v=N6-Q2dgodLs) documents Premiere, After Effects, Figma and a voiceover-first process. Around 5:55 he says that not every video begins with a written script; around 6:07 he describes short recorded phrases. At 7:33 he explains revealing prepared code with Undo; at 7:53 he discusses frame holds. These are dated first-person statements, not a verified 2026 equipment list.

That changes the way you should learn. The polished result does not require flawless live coding. You can prepare a working example, record a clear explanation, then construct the visual sequence that makes the explanation easy to follow. For a beginner, a written script is helpful even though his historical method could be more improvised. Preparation should suit your current skill.

The selected frames of [Python in 100 Seconds](https://www.youtube.com/watch?v=x7X9w_GIm1s) show a large text card around 0:28, an oversized numeral over an image around 0:57, and a visual joke beside code around 1:25. That establishes some visual ingredients. It does not establish an average cut rate, exact keyframe curves or a retention benefit. The following exercises are your own adaptations.

<a id="chapter-01-section-2"></a>
### Choose the format you are learning

Fireship is not one uniform template. A compact concept overview, a news commentary and a project tutorial have different jobs. Start with the compact concept overview. It has the smallest research and filming surface, lets you repeat editing practice, and fits your preference for screen recordings and occasional camera segments.

Your first topic is “A valid JSON answer can still be wrong.” It fits your practical AI/software interests and has a tiny demonstrable contradiction. You do not need an entire AI application. The supplied synthetic example parses successfully and fails a simple arithmetic check. That is enough to teach the distinction without claiming to solve all AI reliability problems.

For your reference map, watch thirty seconds of a chosen reference three ways. First listen for the order of ideas. Second watch muted and name the job of each visual: orient, explain, prove, emphasize or joke. Third watch normally and note when an image appears relative to the spoken idea. Use your own words; do not transcribe or collect an entire asset library from another creator.

Your notes might say: “Definition arrives before history; the key term becomes large text; code appears only when syntax matters.” These are useful observations. “The secret is a cut every 1.7 seconds” is an unsupported rule unless you actually measured that sample, and still would not describe the whole channel. Count visual changes separately from full cuts: a label appearing over code is a new visual beat without a new shot.

<a id="chapter-01-section-3"></a>
### Make a deliberate editor choice

Use [DaVinci Resolve free](https://www.blackmagicdesign.com/products/davinciresolve) for the main learning path. It lets you practice timeline editing, audio, text and basic motion without committing to a subscription. Its current product page identifies Resolve 21; some official training books remain labeled 20. Follow concepts and look up changed controls in the installed version.

If you already have Premiere, use it. The important equivalents are timeline cutting, ripple deletion, markers, transform keyframes, a still/frame hold, text layers and audio gain. After Effects becomes useful for more elaborate motion later; it is not required to make your first clean explainer. Do not buy plugins before you can make a convincing basic title and code highlight yourself.

Open the [official training index](https://www.blackmagicdesign.com/products/davinciresolve/training). This week use Introduction to Editing Part 1 and only the sections needed to import, assemble, trim and export a short clip. It is an inspected learning index, not a claim that every training video was watched during this research. Adobe users can use [Get to know Premiere](https://www.adobe.com/learn/premiere-pro) instead. One completed test matters more than collecting courses.

<a id="chapter-01-section-4"></a>
### Make the first recording before shopping

Record twenty seconds explaining the JSON distinction with your current microphone. Use a quiet room with soft furnishings, turn off distracting fans where practical, and position the microphone consistently. Replay the file. Is the speech clear? Is there an audible room echo? Are strong consonants causing thumps? Is the level clipping? Each problem has a different remedy.

Echo calls for a better room or closer sensible placement before heavier processing. Plosive thumps call for a slight off-axis angle and a pop filter. Clipping calls for lower input gain and a new take. A pricey microphone does not fix a take already recorded with distorted peaks. The [equipment decision](#equipment) gives one straightforward purchase path if your existing recording is the limiting factor.

Import that recording into the editor, split around a mistaken phrase, remove it, and export the result. Listen outside the editor. This confirms the whole chain. Save the working project as a reusable template with separate dialogue, music and sound-effect tracks, and bins named Voice, Screens, Graphics and Exports. You can change the names; the purpose is separating material you need to find quickly.

<a id="chapter-01-section-5"></a>
### This week's practice blocks

| Day | Minutes | Concrete action |
| --- | ---: | --- |
| Monday | 60 | Watch the production reference and make a one-page decision map |
| Tuesday | 75 | Choose your editor and complete the relevant beginner import/trim lesson |
| Wednesday | 60 | Record and compare three 20-second audio takes with placement changes |
| Thursday | 75 | Import, cut and export the cleanest take |
| Friday | 30 | Decide whether equipment solves an observed problem |
| Saturday | 150 | Build and label the reusable project; test a screen clip |
| Sunday | 60 | Inspect the export and write the next specific improvement |

You are ready for lesson 2 when your recording is intelligible, your exported file plays, and you can identify the next skill to improve. Keep the test as your baseline. A better six-week result should be obvious when compared with it.


[Back to contents](#contents)


---

<a id="chapter-02"></a>
## 02 — Write for spoken clarity and plan what the viewer sees

**Your result:** one original short script and a visual plan for every sentence. This week is about selecting information. Faster speech cannot rescue an explanation that includes too many unrelated ideas.

<a id="chapter-02-section-1"></a>
### Start with one transformation

Before writing a hook, finish this statement: “A developer who watches this will be able to distinguish____from____.” For the recurring example, it is “an answer that parses as JSON from an answer whose calculation is correct.” That outcome is narrower and more filmable than “learn AI reliability.” The viewer already knows basic code and JSON. They do not need an explanation of every bracket.

The scope determines the script. Show the incorrect result, show that parsing succeeds, run the additional check, then explain the limitation. You can mention that real applications need domain-specific checks without teaching all evaluation methodology. A precise omission is part of good short-form explanation. An essential missing step is a defect; an unrelated missing chapter is not.

Write a rough paragraph in plain language. Then cut throat-clearing: your biography, a general history of AI, a long greeting and a promise to explain what you are about to explain. Put the interesting object on screen while you name it. “This answer is valid JSON. It also says two plus two is five” gives the viewer a concrete contradiction immediately.

<a id="chapter-02-section-2"></a>
### Build a five-part spine

Use problem → mental model → demonstration → qualification → payoff. The problem earns attention. The mental model distinguishes format from meaning. The demonstration shows a successful parse and failed correctness check. The qualification prevents an exaggerated claim that arithmetic assertions solve all model errors. The payoff gives the viewer one practice to apply: define a check for the actual task.

Do not confuse a hook with an unrelated dramatic statement. A claim about replacing all software engineers creates an expectation this tiny demonstration cannot fulfill. A joke can sharpen the problem instead: “Perfectly formatted nonsense is still nonsense.” That is an original line you can adapt, not a requirement to imitate Jeff's voice or recurring catchphrases.

For a ninety-second practice film, start around 190–220 spoken words, then rehearse. At 150 words per minute, 210 words take 84 seconds before added pauses or silent screen actions. That is a planning calculation, not a measured Fireship narration speed. If you need fifteen extra seconds to show an output, shorten the text or let the final duration grow. A complete clear 105-second lesson is better than rushing to hit an arbitrary number.

<a id="chapter-02-section-3"></a>
### Edit sentences before adding effects

Prefer concrete verbs. “We validate the result” is vague unless the viewer knows what validation means here. “We compare the returned sum with the two input numbers” describes an operation you can show. Replace a pile of nouns with a visible action. Read each sentence aloud and underline the word the picture must clarify.

Give each sentence a job. Definitions establish a concept. Evidence supports it. Transitions explain why the next step follows. Qualifications limit the claim. Humour changes the emotional rhythm. If two adjacent sentences do the same job without adding information, combine them. If a sentence needs a dense diagram and four new terms, simplify or split it.

Use contrast selectively: expected versus observed, input versus output, parse versus check. Do not make every sentence a clever reversal. Constant punchlines leave no stable explanation. For your first short, one or two original jokes are enough practice; the code and argument carry the lesson.

<a id="chapter-02-section-4"></a>
### Storyboard in three columns

You do not need drawing skill. Use Narration, Visible Evidence and Edit. A row might say: “The parser accepts it” / the actual terminal printsParsed:True / hold long enough to read, then highlightTrue. Another might say: “The arithmetic check disagrees” / actualFalse output / cut on the wordcheck and add a restrained error label. This prevents the expensive habit of inventing every shot after recording.

Separate illustrative graphics from evidence. A large FORMAT/MEANING comparison card is an illustration. A screenshot of the demo's actual output is evidence. A fabricated terminal result that you never ran should not be disguised as evidence. Use the supplied runnable example, inspect its result yourself, then record your own screen.

Match picture changes to idea changes. A code line appearing at the moment it is discussed helps orientation. A random animated background creates motion without meaning. Write the reason for each change. If the only reason is “the screen has been static for two seconds,” ask whether the viewer is still reading something valuable.

<a id="chapter-02-section-5"></a>
### A simple visual vocabulary

Limit your first video to six visual types: result shot, clean code, keyword card, comparison diagram, one original visual joke and one optional camera sentence. Use one font family and two functional accent colors. In the sample, blue meansformatand orange meanscorrectness; keep the same mapping in labels and graphics. Do not depend on color alone—use words or symbols too.

The [sample script and shot list](#sample-script) is fully original and ready to adapt. Read it aloud without trying to sound like Jeff. Mark awkward phrases and substitute words you naturally say. The goal is your own clear, confident delivery at a controlled pace.

<a id="chapter-02-section-6"></a>
### Learn, practise, finish

Monday 60 min: choose the outcome and write a messy first version. Tuesday 75 min: cut it into the five-part spine. Wednesday 60 min: read aloud, record a rehearsal and estimate duration. Thursday 75 min: write the three-column storyboard. Friday 30 min: verify each factual claim and remove unsupported promises. Saturday 150 min: produce the simple diagram, code states and one original joke card. Sunday 60 min: test whether the first fifteen seconds make sense without background explanation.

Resources: revisit the [creator's walkthrough from 4:28](https://www.youtube.com/watch?v=N6-Q2dgodLs&t=268s) for audience framing; use [Python in 100 Seconds](https://www.youtube.com/watch?v=x7X9w_GIm1s) as a viewing exercise rather than a script to rewrite. No external writing course is required before you can perform this exercise.

Your completion criterion is concrete: every sentence has a purpose and a feasible visual, the first sentence reaches the real subject, and the payoff fulfills the promise. Keep removed ideas in a separate file so scope stays small without losing future topics.


[Back to contents](#contents)


---

<a id="chapter-03"></a>
## 03 — Record useful pieces and build the voice track first

**Your result:** the finished narration for one short explainer, plus clean screen clips. You should already have the script, storyboard and an editor that successfully exports a test.

<a id="chapter-03-section-1"></a>
### Make the audio the structural backbone

An audio-first edit lets you solve the argument and delivery before spending time animating it. Record one or two sentences at a time. Leave a small margin before and after each take. If you stumble, pause and repeat the whole phrase with the same energy rather than restarting the entire video. Later you can choose the better take without rebuilding everything around it.

Use a slightly more deliberate delivery than a casual conversation, while keeping your normal voice. Emphasize the important word, not every word. “The JSON is valid. The answer is wrong.” needs a small separation so the contradiction lands. Increasing playback speed changes timbre and comprehension; perform the line at the desired energy instead.

Keep a consistent mouth-to-microphone relationship. Start around 10–15 cm for a suitable close-talk mic, test the manufacturer's guidance, then adjust for plosives and tone. Do not assume all microphones accept the same distance or speak into the same side. Aim slightly away from the breath stream and use a windscreen or pop filter where needed. [Shure recording education](https://www.shure.com/en-US/docs/education/Microphone-Techniques-for-Recording) explains placement as an important part of the recording chain.

Set gain with the loudest sentence you expect to say. An initial peak range around −12 to −6 dBFS gives room for variation; it is a practical starting point, not a loudness standard or a description of Jeff's settings. Avoid hitting 0 dBFS. Record a few seconds of room sound so abrupt changes in background noise become easier to notice during the edit.

<a id="chapter-03-section-2"></a>
### Record with the simplest reliable route

You may record directly into a mono dialogue track in your editor, or record a microphone-only scene in OBS and use that audio. Direct editor recording is convenient after you have tested input routing. OBS is useful when you want a consistent source setup. Disable duplicate input capture so your microphone is not accidentally recorded twice with a short delay.

Follow the [OBS Quick Start](https://obsproject.com/kb/quick-start-guide) for scene, source and audio setup. Use [Hybrid MP4](https://obsproject.com/kb/hybrid-mp4) with compatible H.264/AAC if your short import test succeeds; MKV plus remux is a useful fallback. These are current container choices, not an instruction to change an already reliable workflow. Record and import a thirty-second sample before a large session.

Create a dedicated browser profile with synthetic data and hide notifications. For a 1920×1080 screen recording, enlarge the editor font until the important line is readable in a small preview. Start around 24–32 pixels and judge the actual export; different fonts and zoom levels vary. Show the relevant pane, not a whole desktop full of tiny text.

<a id="chapter-03-section-3"></a>
### Assemble the narration

Place the chosen takes on the dialogue track in story order. Remove mistakes, repeated starts and pauses that do no work. Listen without visuals. Does the argument make sense? Are any edits swallowing consonants? Are you forcing the viewer to process two difficult ideas without a breath? Repair those issues before adding motion.

Use short fades or tiny crossfades where a cut produces an audible click. A click often comes from a waveform discontinuity; covering every edit with a large dissolve is unnecessary. Preserve natural breaths when they support cadence. Remove a distracting breath individually rather than applying aggressive gating that makes every word sound isolated.

Balance phrase levels with clip gain first. Compression can reduce excessive dynamic variation; it cannot undo clipped audio. A de-esser can reduce harsh sibilance; it should not turn speech into a lisp. Equalization should address a heard problem, such as muddiness, rather than copy someone else's numerical preset. Compare processed and raw audio at similar perceived volume so louder does not automatically seem better.

Adobe users can tag clips as Dialogue and use the documented [Essential Sound controls](https://helpx.adobe.com/uk/premiere/desktop/add-audio-effects/adjust-volume-and-levels/audio-editing-with-essential-sound-panel.html). [Auto-Match](https://helpx.adobe.com/in/premiere/desktop/add-audio-effects/adjust-volume-and-levels/auto-match-audio-loudness.html) helps align clips, but its displayed target is not a universal YouTube setting. Resolve users should use the [official Fairlight learning sections](https://www.blackmagicdesign.com/products/davinciresolve/training) for Recording VO and ADR and introductory audio, applying only what the current task needs.

<a id="chapter-03-section-4"></a>
### Capture code as prepared visual states

Finish and test the example before recording the teaching footage. Capture the initial result, the input, the relevant check and the final output as separate clips. Each clip needs a second or two of stillness before and after its important action. That gives you clean editing handles.

One useful reconstruction method is to remove prepared code in reverse teaching order, begin recording, then useUndo to reveal those blocks in forward order. Another is to record deliberate pastes. Keep the original code safe and verify the restored example afterward. This is an edited explanation, not a speed-coding demonstration; do not suggest the implementation was written instantly or generated by a tool if it was not.

When the narration needs longer than the screen action, hold a clean frame rather than repeatedly slowing the mouse movement. A viewer should not watch your cursor drift merely because the sentence is unfinished. Lesson 4 shows how to build holds and highlights. For your optional face segment, record one short orientation or closing sentence at eye level with a window or soft lamp and the same consistent audio.

<a id="chapter-03-section-5"></a>
### This week's practice

Monday 60 min: test placement, levels and input routing. Tuesday 75 min: record the script in short phrases. Wednesday 60 min: select takes and assemble dialogue. Thursday 75 min: repair timing and level differences. Friday 30 min: listen on headphones and ordinary speakers. Saturday 150 min: capture the prepared code/output states and optional camera sentence. Sunday 60 min: export an audio-led rough version and mark every confusing transition.

Done means the narration works by itself, no phrase clips or vanishes at an edit, and every essential screen action exists in a usable clip. That is the foundation for energetic editing. Effects cannot substitute for it.


[Back to contents](#contents)


---

<a id="chapter-04"></a>
## 04 — Learn seven editing moves and reuse them

**Your result:** a small library of original reusable edits. You need only one editor. Each recipe below has a purpose, procedure, practice task and failure test. The numerical timings are course starting points, not measured Fireship presets.

At 30 frames per second, six frames last 0.2 seconds. A keyframe records a property's value at a moment in time; the editor calculates the values between keyframes. Easing changes how quickly that change begins or ends. [Adobe's keyframe guide](https://helpx.adobe.com/premiere/desktop/add-video-effects/control-effects-and-transitions-using-keyframes/about-keyframes.html) provides a current explanation. In Resolve, start with the Inspector for clip transforms and titles; use Fusion later for composites that genuinely need it.

<a id="chapter-04-section-1"></a>
### Move 1: cut when the idea changes

**Job:** move attention to the object the narration now discusses.

1. Put a marker on the important spoken noun or verb: “parser,” “sum,” “check.”
2. Place the relevant shot so the object becomes visible at or just before that word.
3. Cut away the preceding shot's dead tail.
4. Replay two seconds before and after the cut. The viewer should know why the picture changed.

Use hard cuts as the default. A dissolve suggests continuity or elapsed time and can blur code unnecessarily. A visual beat can also be an annotation appearing while the same shot remains. Do not manufacture a full cut merely to satisfy a quota. Practise three cuts in a fifteen-second explanation, then remove any that makes the idea harder to follow.

**Failure test:** watch muted. If the shots seem unrelated, improve the visual relationship or the transition sentence. Watch with audio. If the new shot arrives after the important word, adjust timing. Smoothness is subordinate to meaning.

<a id="chapter-04-section-2"></a>
### Move 2: a large keyword card with a controlled pop

**Job:** make one central distinction memorable.

1. Add a solid background and a short title on a layer above it. Use your own color and type choices.
2. For the word FORMAT, start the title slightly smaller, around 90% of its final size.
3. Set another scale keyframe six frames later at 100%.
4. Apply a gentle ease-out if available. Preview; the motion should settle rather than float indefinitely.
5. Hold the settled word while it is relevant, then cut to the evidence.

Resolve: use a Text or Text+ title and its available transform controls. Premiere: use a text graphic and scale/position keyframes in its controls. An optional overshoot adds a brief 104% state before settling to 100%; remove it if the word becomes harder to read. None of these values is a secret creator setting.

Make three cards: FORMAT, MEANING and CHECK. Save them in your project template. A phrase with two important words may need two beats; a full sentence in a tiny rectangle needs rewriting. Practise reading the card in a small preview before animating it further.

<a id="chapter-04-section-3"></a>
### Move 3: a deliberate punch-in

**Job:** guide the eye to a specific result or line.

1. Begin with enough context to orient the viewer.
2. At the narration's emphasis, change scale from 100% to roughly 115% over six to ten frames.
3. Adjust position so the relevant line remains inside the frame.
4. Hold while you explain, then cut or return when context becomes useful again.

This is a teaching zoom, not a reason to enlarge every clip repeatedly. If you zoom on a low-resolution recording, the code may soften. Prefer capturing a tighter window with larger text; higher source resolution can help when the computer handles it reliably, but readable composition comes first.

Resolve: select the clip, use Inspector Transform controls and their keyframe diamonds. Premiere: use the clip's Motion Scale and Position properties. The exact panel layout varies with version. Learn two keyframes on an ordinary clip before attempting a complex animated camera.

**Failure test:** cover your annotation. Can someone identify the line being discussed? If not, the zoom may not be enough; use a highlight as well. If the text moves during the moment it must be read, settle earlier.

<a id="chapter-04-section-4"></a>
### Move 4: freeze the evidence and highlight one line

**Job:** decouple reading time from how quickly an action happened.

1. Choose a frame where the code or output is complete and the cursor is unobtrusive.
2. Create a still/frame hold using the installed editor's freeze command. Importing an exported still is a simple fallback.
3. Extend that still to match the explanation.
4. Put a translucent rectangle behind or beside the relevant line, with enough contrast to preserve the code.
5. Add a small label such as PARSES or WRONG SUM only if it clarifies the claim.

Adobe documents [Frame Hold](https://helpx.adobe.com/ph_en/premiere/desktop/edit-projects/change-clip-speed/freeze-a-video-frame-for-the-duration-of-a-clip.html) and a separate [Time Remapping hold](https://helpx.adobe.com/uk/premiere/desktop/organize-media/file-organization/freeze-a-frame-for-a-portion-of-a-clip-using-time-remapping.html). Use the simpler whole-clip still for this drill. Resolve users can find the current freeze-frame operation through command search or use a still image; the communication result matters more than matching another editor's shortcut.

Practise a four-second hold on the false result. Do not stretch a moving action if the only purpose is to keep text visible. A still lets the viewer read without confusing slow mouse movement. Check whether an animated selection cursor or an autocomplete panel accidentally obscures the evidence.

<a id="chapter-04-section-5"></a>
### Move 5: reveal code in meaningful blocks

**Job:** let the viewer connect one operation with one explanation.

1. Decide the teaching order: input, parse, check, output.
2. Record those states using a prepared Undo/paste sequence or capture separate screenshots.
3. Align each reveal with the corresponding narration.
4. Hold the final state long enough to understand the relationship.

Reveal complete meaningful units, not necessarily individual keystrokes. Typing animation can be attractive while wasting time on punctuation. A three-line expression should appear together if its meaning depends on all three lines. A brief crop or label can direct attention without hiding earlier context.

Your small demo is deterministic. Record it as an explanation of tested code, not a claim about how fast you originally wrote it. In a real application, test the restored state before recording the output. A visual reveal that accidentally omits a necessary import teaches a broken example.

<a id="chapter-04-section-6"></a>
### Move 6: build a diagram one relationship at a time

**Job:** make the system boundary understandable without a wall of text.

1. Draw three original cards:MODEL RESPONSE → PARSE → DOMAIN CHECK.
2. Start with the first card visible.
3. Reveal the second when you discuss structure.
4. Reveal the third when you discuss the task-specific correctness test.
5. Mark the second as pass and the third as fail using words plus symbols, not color alone.

You can make these as separate transparent images or text/shapes in the editor. Animate opacity or position modestly. Keep old objects in place while adding the next relationship so the viewer can build a mental model. Replacing the entire diagram at every sentence forces unnecessary reorientation.

Resolve's [Fusion training](https://www.blackmagicdesign.com/products/davinciresolve/training) is useful once you need connected composites; Introduction to Fusion should precede more elaborate motion graphics. Premiere users can make basic cards directly and use [After Effects learning](https://www.adobe.com/learn/after-effects) when needed. Do not make a 3D scene to explain a relationship three flat cards already communicate.

<a id="chapter-04-section-7"></a>
### Move 7: make one visual joke serve the concept

**Job:** create a brief release that reinforces the lesson.

1. Write the underlying contradiction in plain language.
2. Invent an original image treatment—for example, a polished certificate labeled OFFICIALLY WRONG beside the neatly formatted false sum.
3. Place it at the punchline, briefly enough to keep the argument moving, long enough to recognize.
4. Optionally add one quiet, licensed sound accent.
5. Return to the explanation with no extra transition unless one is needed.

Make the joke about the situation, not a claim that another person or tool did something you have not demonstrated. Do not collect and reuse a creator's branded animations, signature catchphrase, voice, thumbnail or meme sequence. Your creative advantage is a technical observation expressed in your own humour.

Avoid stacking a joke, new code, a flashing title and a loud effect at the same moment. One carries the meaning; the others should support it. Check the video without music. If the joke only works because the sound is startling, improve the visual idea or remove it.

<a id="chapter-04-section-8"></a>
### Practise the moves as a kit

Monday 60 min: create a fifteen-second cut sequence. Tuesday 75 min: make three reusable keyword cards. Wednesday 60 min: practise a punch-in that stays readable. Thursday 75 min: make the freeze/highlight and block reveal. Friday 30 min: remove one unnecessary flourish. Saturday 150 min: build the diagram and original joke; save everything in the template. Sunday 60 min: assemble a thirty-second technique reel and inspect it on a phone.

Open the [editing lab](editing-lab.html) to scrub an original miniature sequence and compare linear motion with ease-out. It demonstrates timing, holds and hierarchy; it does not render a real editor project or contain Fireship footage. Reproduce the useful behavior in your chosen editor. Done means you can explain why each move exists and apply it without searching for a new tutorial every time.


[Back to contents](#contents)


---

<a id="chapter-05"></a>
## 05 — Assemble one complete video and finish it carefully

**Your result:** a complete original 90–150-second developer explainer. You have edited narration, tested screen evidence and seven reusable moves. This week combines them in a sensible order.

<a id="chapter-05-section-1"></a>
### Pass 1: the audio-led assembly

Duplicate your template and save a new project. Put the completed dialogue on its own track. Add markers for the hook, explanation, demonstration, limitation and payoff. Do not change the argument every time you discover an attractive animation. If the argument is still wrong, return to the script before polishing.

Place the main evidence shots first: the incorrect result, successful parse, failed arithmetic check and corrected example. These are the video's load-bearing images. Then fill the transitions with simple code states or diagrams. Only after the lesson works should you add keyword pops and a joke. This order protects the explanation from being buried under decoration.

Use separate tracks for evidence, graphics and titles where your editor allows. Name tracks or clips so you can find the right material. Keep music and sound effects separate from dialogue. If a title accidentally obscures a result, you should be able to move it without rebuilding the recording.

<a id="chapter-05-section-2"></a>
### Pass 2: timing and comprehension

Replay each sentence and ask what the viewer must inspect at that moment. If the sentence names an object not yet visible, adjust the shot. If the important code changes before it can be read, extend a hold. If the diagram stays after its explanatory job ends, shorten it. The desired speed follows comprehension.

You can use a few two-to-five-second visual beats as a starting exercise, with longer holds for code and diagrams. This is your practice range, not a measured average or a rule for every video. A new label can supply a beat without a full cut. Meaningful variation is more useful than a fixed timer.

Make the first fifteen seconds especially concrete. Show the contradiction, identify the topic and establish that you have evidence. Do not spend that time listing the channel's future promises. The ending should give the answer the opening implied: parsing checks format; correctness requires a test for the task. A brief next step may follow, but the lesson should already be complete.

<a id="chapter-05-section-3"></a>
### Pass 3: sound design

Begin with dialogue that is comfortable without music. Then add background music only if it improves the experience. Use a track with suitable rights, such as one chosen under the [YouTube Audio Library's actual conditions](https://support.google.com/youtube/answer/3376882). Check track-specific attribution. A public GIF or popular sound clip does not automatically include permission for your use.

Lower music until every technical word remains effortless to understand on ordinary speakers. Different recordings have different loudness, so “music at −25 dB” is not a universal mix recipe. Use volume automation to reduce it during dense explanations or important quiet lines. Adobe's current [ducking guidance](https://helpx.adobe.com/premiere/desktop/add-audio-effects/adjust-volume-and-levels/automatically-duck-audio.html) describes automation, but generated keyframes still need review.

Use a small sound palette: perhaps a restrained tick for an appearing label and a quiet impact for the single punchline. Vary silence too. Do not place a sound on every cut. A sound accent should not force someone to turn down the volume after they adjusted it for your voice.

<a id="chapter-05-section-4"></a>
### Pass 4: readable graphics and a finished picture

Check the video at a small viewing size. Can you read the important output? Do you know which line the narration discusses? Do the labels agree with the code? Does the highlighted color retain meaning throughout? Remove fine detail that becomes visual noise. A full IDE window may look technical while communicating less than a tight crop.

For camera footage, correct obvious exposure and white-balance differences. Your optional face sentence should feel like part of the same video, not a reason to learn a cinematic grading workflow. Use a consistent frame rate and avoid unnecessary switches between bright and dark graphics. Dramatic flashes are not required for an energetic technical lesson.

Correct captions for code names and technical terms. Distinguish subtitles from keyword graphics: captions help access the spoken meaning; graphics establish hierarchy. You do not need large animated word-by-word captions covering your code. Check both the actual screen text and the caption track.

<a id="chapter-05-section-5"></a>
### Export, inspect, then decide whether to publish

Export a short problematic section first if you are uncertain about frame holds, fonts or audio. Then export the full video. A simple starting choice is 1920×1080 SDR, the timeline's frame rate, H.264 video and AAC audio at 48 kHz. Refer to [YouTube's current encoding guidance](https://support.google.com/youtube/answer/1722171); its bitrate table is a reference, not a quality guarantee for dense screen footage.

Watch the exported file outside the editor, start to finish. Check the beginning, every evidence shot, the last frame and audio tails. If possible, inspect on a phone as well. A clean editor preview does not prove the export is correct. Fix missing graphics, clipped sound, unreadable code and inaccurate claims before deciding to upload.

Give yourself an overnight break before the final review when the schedule allows. You are more likely to notice a confusing transition after forgetting the sentence you intended to say. Ask one appropriate viewer what they understood the demonstration to establish. Do not coach them toward your desired interpretation.

<a id="chapter-05-section-6"></a>
### This week's blocks

Monday 60 min: audio markers and main evidence. Tuesday 75 min: diagrams and code reveals. Wednesday 60 min: first-fifteen-second revision. Thursday 75 min: restrained motion and one original joke. Friday 30 min: dialogue/music balance. Saturday 150 min: captions, export and small-screen inspection. Sunday 60 min: fresh-eye review and specific repairs. That totals 8.5 hours.

Your result can remain a private practice video. The goal is a complete artifact with a coherent promise, accurate proof, comfortable sound and controlled visual rhythm. Publishing quality grows through finished revisions, not indefinitely polishing a project you never watch from beginning to end.


[Back to contents](#contents)


---

<a id="chapter-06"></a>
## 06 — Improve by comparison, then use a repeatable cycle

**Your result:** two revisions of your short film, an honest assessment and a plan for the next original video. Six weeks builds a working production skill set. Matching an experienced creator's judgment may take many more completed videos.

<a id="chapter-06-section-1"></a>
### Compare equivalent segments

Take twenty seconds from your video and a relevant reference segment. Compare the job each must accomplish: definition with definition, code explanation with code explanation. Comparing your dense tutorial with a joke montage tells you little about the appropriate pacing. Describe differences precisely rather than saying “mine does not feel professional.”

For sound, listen for consistency, clear consonants, unwanted noise and useful pauses. For scripting, identify how quickly each segment reaches its subject and how many new ideas it introduces. For visuals, ask whether the object discussed is visible and whether it remains long enough to understand. For humour, ask whether the joke sharpens the point or interrupts it.

Do not use cut count as the overall grade. You can double cuts while making a lesson worse. Do not use a creator's public views as proof that a particular zoom caused success. Your first quality target is an accurate lesson that a matching viewer wants to keep watching. Audience response becomes additional evidence once you have enough relevant viewing.

<a id="chapter-06-section-2"></a>
### Use a small practical rubric

| Dimension | Needs work | Ready for this exercise | Stronger version |
| --- | --- | --- | --- |
| Promise | Topic stays vague | Outcome is clear immediately | Hook makes the exact problem compelling |
| Accuracy | Illustration implies more than tested | Evidence and limits match | Test conditions are effortless to follow |
| Narration | Distortion, inconsistent level or rushed clauses | Comfortable intelligible speech | Emphasis and pauses guide understanding |
| Visual clarity | Tiny code, late labels | Relevant object readable | Layout anticipates the viewer's next question |
| Rhythm | Dead waits or constant unrelated changes | Cuts serve ideas | Holds, motion and silence create deliberate contrast |
| Originality | Borrowed persona or assets | Own wording and visual treatment | Technical perspective and humour feel distinctive |

This rubric is a self-review aid, not a scientific score predicting retention. A defect in accuracy or intelligibility blocks release even if the graphics are excellent. A modest visual style can still produce a useful first video. Do not hide a serious defect behind a high average score.

<a id="chapter-06-section-3"></a>
### Make only one major change per revision

RevisionA improves the argument. Remove one redundant explanation, fix the slow opening and ensure every claim has matching proof. Leave motion mostly alone. RevisionB improves delivery: make one difficult screen readable, repair a loudness change and remove a distracting effect. Export both so you can compare the actual result rather than relying on memory.

Record time and the effect of each change. “Forty minutes replacing a denseIDEshot with two cropped states made the check readable” is useful. “Bought another effects pack” does not identify an improvement. If a technique adds two hours without making the result clearer or more engaging, use a simpler version next time.

Ask for a reaction from someone who resembles your viewer. Useful prompts include “What did the check prove?” and “Which moment was hard to follow?” Their answer can expose a missing explanation. A compliment is encouraging but does not establish that the lesson worked. Respect their time; a ninety-second practice film does not need a formal focus group.

<a id="chapter-06-section-4"></a>
### Pick the next three practice topics

For your strengths, use one visible contradiction each: “Your extension popup is not a database,” “A local tool still needs an export plan,” and “A model can improve accuracy while missing the important cases.” These are premises to reproduce and research before making claims. Keep the first video about JSON as your production exercise; do not expand all four into a new channel strategy today.

The second video should reuse your typography, highlight treatment, sound palette and project bins. It should have new teaching content and original evidence. The purpose of a template is to save layout and routing decisions, not to mass-produce the same explanation with a new title.

After two short explainers, try a 3–5-minute version only if the subject needs more reasoning. Add meaningful intermediate states and one extra example rather than slower delivery and repeated points. Longer formats require stronger orientation. Use short labels to show where you are in the argument.

<a id="chapter-06-section-5"></a>
### Turn practice into a two-week production habit

Use the [production playbook](#playbook). Its 17-hour cycle assumes a small tested demonstration and the template you have built. If you need a new complex project, count that work separately and reduce scope or extend the schedule. An experienced creator's release cadence is not evidence that your first complex explanation should fit one evening.

Keep a hard limit on new tool learning. Optional AI assistance can flag redundant sentences, prepare a first caption draft or suggest a shot list. You inspect each suggestion. Preserve your own voice and recorded evidence. No voice clone, automatic meme package or “viral score” substitutes for editorial judgment.

Monday 60 min: compare two equivalent segments. Tuesday 75 min: write and perform Revision A. Wednesday 60 min: export and inspect. Thursday 75 min: perform Revision B. Friday 30 min: ask for focused feedback where available. Saturday 150 min: revise the template and brief the next video. Sunday 60 min: record your measured time, choose one weakness and schedule the next cycle.

Your durable achievement is a repeatable method: reproduce the result, narrow the explanation, assemble the voice, show evidence at the right moment, use a few purposeful graphics and review the finished file. Keep practicing that method. The style becomes yours through the problems you choose, the precision of your explanation and the way you make those problems entertaining.


[Back to contents](#contents)


---

<a id="equipment"></a>
## Equipment: make one sensible purchase, then practise

**My recommendation:** test your current microphone first. If it is the weak link, choose a USB dynamic microphone, use existing wired headphones, keep your computer, and use your phone/webcam for occasional face segments. Jeff's exact current microphone and room are not verified here. This is a recommended kit for you, not a reproduction of his desk.

<a id="equipment-section-1"></a>
### What to buy or use

| Priority | Choice | Why | Price status |
| --- | --- | --- | --- |
| First, if needed | [Shure MV6 Gen 2](https://www.shure.com/en-US/products/microphones/mv6) | Straightforward USB recording and monitoring; use the included stand before adding accessories | Manufacturer's September 2026 announcement lists US$169; check current checkout price, tax and availability |
| Lower-cost alternative | [FIFINE AM8](https://fifinemicrophone.com/collections/all-fifine-products/products/fifine-am8-microphone-official) | USB/XLR dynamic option; use USB, without a separate interface | Official page displayed US$57.99 on 13 November 2026, but also a back-in-stock interface; stock/variant not confirmed |
| Already own | Wired headphones | Hear clicks, plosives and edit problems | Additional $0 if you own a usable pair |
| Already own | Computer and phone/webcam | Screen recording plus brief camera segments | Additional $0 if existing hardware passes the sample test |
| Optional after testing | Compatible boom arm and pop filter | Better placement and fewer desk bumps | Planning allowance$40–70, not a researched product quote |
| Optional for face footage | Stable phone mount and soft light/window | Eye-level framing and consistent exposure | Begin with what you have; no specific purchase required |

The [Shure announcement](https://www.shure.com/en-US/newsroom/shure-introduces-next-generation-of-the-mv6-usb-gaming-microphone) provides the dated price. Product pages establish specifications, not an independent sound-quality ranking. No sample from these microphones was recorded or compared for this course. Buy from an appropriate seller with return terms and check your computer's ports.

**Budget example:** $169 mic + $50 accessory allowance = $219 before tax/shipping, assuming existing headphones, computer and camera. You can begin at $169 with the included stand. A better room/position can be a more useful first change than any purchase. A dynamic capsule does not automatically remove background noise; distance, direction and environment matter.

The Audio-Technica ATR2100x-USB appears in many older recommendations, but its [current official US page](https://www.audio-technica.com/en-us/atr2100x-usb) says discontinued. I would not make it your default new purchase based on an old guide.

<a id="equipment-section-2"></a>
### Software: choose once

Default: [DaVinci Resolve free](https://www.blackmagicdesign.com/products/davinciresolve) + [OBS](https://obsproject.com/) + a simple graphics tool you already know. Resolve 21 is the researched live product baseline. Use the free edition's core tools; this course does not require Studio AI features.

If you already pay for Premiere, stay with it. [Premiere training](https://www.adobe.com/learn/premiere-pro) and [After Effects training](https://www.adobe.com/learn/after-effects) support a route closer to the documented historical tool choices. A paid subscription is not evidence your edit will improve. Current Adobe costs and entitlements depend on plan/region; inspect them before committing.

Do not buy a new camera, green screen, audio interface, high-end XLR mic, editing keyboard or effects subscription for the first practice video. Add equipment when a specific observed failure justifies it. Before changing computers, test a short 1080p project and proxy/preview options on what you have.


[Back to contents](#contents)


---

<a id="playbook"></a>
## The repeatable production playbook

Use this after the six lessons. **One small, original 90–150-second explainer; 17 hours over two weeks.** This is an initial allowance, not a claim about Fireship's production speed. A new complex build or extensive research needs more time or a smaller premise.

<a id="playbook-section-1"></a>
### The sequence

| Step | Time | Action | Finished when |
| --- | ---: | --- | --- |
| 1 | 30 min | Choose one developer problem and audience | One sentence states what the viewer will understand afterward |
| 2 | 150 min | Reproduce the result and verify the important claims | Working code, real output and known limitations exist |
| 3 | 90 min | Write a short spoken script | Hook, explanation, proof, qualification and payoff are present |
| 4 | 60 min | Map every sentence to a visual | Each row names narration, evidence and edit |
| 5 | 60 min | Record narration in small phrases | Clean takes cover the whole script |
| 6 | 90 min | Assemble and balance dialogue | Audio alone makes sense and remains comfortable |
| 7 | 90 min | Capture prepared screen states | Code/output clips match the narration and are readable |
| 8 | 120 min | Place evidence and simple diagrams | The entire explanation works with minimal decoration |
| 9 | 90 min | Add selected typography, highlights and motion | Each effect has a stated communication job |
| 10 | 30 min | Add restrained music/effects, if useful | Words remain effortless to understand |
| 11 | 90 min | Correct captions, export and inspect on a small screen | Complete exported file passes the quality checks |
| 12 | 60 min | Return with fresh eyes; revise and prepare packaging | Promise, opening and payoff agree; next improvement is recorded |
| **Protected buffer** | **60 min** | Handle an unexpected repair | Never treat this as permanent customer-delivery capacity |
| **Total** | **1,020 min** | **17 hours** | **One finished small explainer** |

<a id="playbook-section-2"></a>
### Keep the editing order

**Argument → voice → evidence → supporting graphics → sound → final inspection.** If the explanation fails at an earlier stage, fix it there. Do not animate around an inaccurate claim or a missing result.

Use the template you built. Keep dialogue separate from music and effects. Use a small original visual kit: one title style, a keyword card, a code highlight, a result comparison and a three-card diagram. Choose a few useful moves rather than forcing all seven into every video.

<a id="playbook-section-3"></a>
### The first fifteen seconds

Show the actual result or contradiction. Name the problem in plain language. Make the expected payoff clear. For the sample: a neatly formatted wrong answer, a successful parse and the promise of a separate correctness check. Skip a long logo intro and a personal résumé. A short camera line is optional when it helps connect the lesson to you.

<a id="playbook-section-4"></a>
### The sound checks

- No clipped peaks, swallowed words or accidental double microphone capture.
- Phrases have a consistent perceived level.
- Pauses are deliberate; consonants and breaths still sound natural.
- Music and effects remain subordinate to speech on ordinary speakers.
- Processing improves the recording when compared at matched loudness.

<a id="playbook-section-5"></a>
### The picture checks

- The currently discussed object is visible.
- Code and output are readable in a small preview.
- New ideas get useful changes; difficult ideas get enough time.
- Important lines have restrained highlights and clear labels.
- Actual results are distinguishable from illustrative graphics or staged fixtures.
- The joke and graphics are original or appropriately licensed.

<a id="playbook-section-6"></a>
### The final decision

Watch the exported video all the way through, outside the editor. Fix missing assets, factual problems, unreadable evidence and distracting sound before publishing. A high effects count does not compensate for these failures. Save the script, sources, editable project and final export together.

Then record four things: actual hours by stage, one moment that worked, one specific weakness and one improvement for the next video. If this tiny film took 30 hours, do not promise a weekly five-minute film. Identify the slow stage, simplify the next topic and use the same kit again.

Once you can make two clear short explainers, move to 3–5 minutes when the teaching genuinely needs more reasoning. Reuse the method and add useful examples. Matching another creator's polish is a direction for practice, not a guaranteed deadline.


[Back to contents](#contents)


---

<a id="sample-script"></a>
## Original practice film: “Your JSON is valid. The answer is still wrong.”

This is an original script for Aadil, not a Fireship transcript or imitation of Jeff's voice. Treat runtime as a rehearsal result. The footage is a synthetic arithmetic demonstration; it is not a benchmark of a particular AI model.

The narration below has 184 whitespace-separated words: about 73.6 seconds at 150 words/minute before pauses and screen-reading time. The ninety-second storyboard therefore leaves roughly sixteen seconds for those holds. Rehearse and adjust rather than speeding up to match the table.

<a id="sample-script-section-1"></a>
### Narration

This answer is valid JSON. It also says two plus two is five. Apparently, formatting has solved mathematics.

When you ask a model for structured output, there are different questions hiding inside the word“valid.” Can your application read the response? Does it have the fields you expect? And is the answer actually correct?

Watch this tiny example. The response contains two numbers and a sum. Python's JSON parser accepts it. Our field check accepts it too. But the arithmetic check compares the returned sum with the inputs—and fails.

That's the distinction. Structure tells your program how to read an answer. A task-specific check tells it something about whether that answer is usable.

Here, the check is easy because addition has a definite result. In a research summary, correctness is harder: you need evidence and evaluation suited to the claims. A parser cannot decide whether a citation supports a sentence.

So keep the format checks. Then ask one more question: what would a wrong answer look like in this particular task, and how could I detect it?

Start there. Beautifully organized nonsense is still nonsense.

<a id="sample-script-section-2"></a>
### The shot plan

Durations below are flexible edit allowances. They do not imply the reference creator follows these timings.

| Approximate time | Narration beat | Original visual | Edit |
| --- | --- | --- | --- |
| 0–4s | Valid JSON, wrong sum | Real demo payload showing 2, 2, 5 | Tight crop; sum highlight |
| 4–7s | Formatting joke | Original OFFICIALLY WRONG certificate card | Brief hard cut; optional quiet accent |
| 7–16s | Several meanings of valid | FORMAT/STRUCTURE/CORRECTNESS cards | Reveal one at a time |
| 16–22s | Tiny example | Code input state | Stable readable frame |
| 22–29s | Parser accepts | Actual PARSE: PASS output | Cut on parser; hold |
| 29–35s | Fields accepted | Actual STRUCTURE: PASS output | Add line highlight |
| 35–42s | Arithmetic fails | Actual ARITHMETIC: FAIL output | Small punch-in, then still |
| 42–54s | Explain the distinction | Two-column format/task graphic | No unnecessary motion while reading |
| 54–66s | Easy arithmetic, harder claims | Arithmetic card then original source/claim diagram | Purposeful change between concepts |
| 66–76s | Parser cannot judge evidence | Source card and claim card | Clear text label, no fabricated benchmark |
| 76–90s | Apply the question and payoff | A single review question, then a clean end card | Hold for meaning; end after payoff |

<a id="sample-script-section-3"></a>
### Make the evidence

Run [json_demo.py](assets/json_demo.py) with Python 3. It prints:

```text
PARSE: PASS
STRUCTURE: PASS
ARITHMETIC: FAIL
```

Use the provided bad fixturefor the video and verify the good fixtureas a control. This demonstrates layered checks for one toy task. It does not implement semantic truth checking, a general schema validator, an AI integration or a hallucination detector.

<a id="sample-script-section-4"></a>
### A simple editorial-assistant prompt

“Review my original short developer-explainer script. The viewer knows basic Python and JSON. Identify redundant sentences, missing logical steps and claims stronger than the demonstration. Suggest a three-column narration/visual/edit plan. Keep my wording natural, preserve limitations, and do not imitate a named creator's voice or invent test results. Return a revised draft and a claim checklist. I will rehearse and verify it.”

That is a suggested learner prompt. No assistant or tool was used to film or validate your future media by creating this course.


[Back to contents](#contents)


---

<a id="sources"></a>
## Research and evidence

Access date: 13 November 2026. This is a focused production adaptation. Training indexes were inspected, not completed as courses. Product claims come from primary vendor pages, not hands-on equipment tests. Original tutorial recipes, timings, budgets and scripts are authored recommendations.

| Source | What was inspected | Boundary |
| --- | --- | --- |
| [Jeff Delaney: How I Make Videos for Programmers, 2020](https://www.youtube.com/watch?v=N6-Q2dgodLs) | Direct YouTube transcript, auto-generated captions; selected playback frames near 5:25 and 6:19 | Historical self-report and visible editor frame, not current private setup; exact transcript errors possible |
| [Fireship: Python in 100 Seconds](https://www.youtube.com/watch?v=x7X9w_GIm1s) | Direct transcript and sampled frames near 0:05, 0:28, 0:57, 1:25 | Selected still observations; no complete frame-by-frame edit or sound analysis, no channel-wide cut-rate measurement |
| [CultRepo interview](https://www.youtube.com/watch?v=XRoSBWYMefY) | Public page opened | Transcript unavailable during the attempt; not relied on for new process claims |
| [Blackmagic training](https://www.blackmagicdesign.com/products/davinciresolve/training) | Relevant editing, audio,VO, Fusion and delivery index entries | Learning resources, not a claim of operating Resolve |
| [Resolve product](https://www.blackmagicdesign.com/products/davinciresolve) | Current product baseline and free option | Version 21; learner's hardware and installation untested |
| [Premiere learning](https://www.adobe.com/learn/premiere-pro) | Current tutorial index | Choose relevant beginner tasks; no need to complete everything |
| [After Effects learning](https://www.adobe.com/learn/after-effects) | Index and [text-animation lesson](https://www.adobe.com/learn/after-effects/web/create-fluid-text-animations) | Optional motion path, not required for first film |
| [Premiere keyframes](https://helpx.adobe.com/premiere/desktop/add-video-effects/control-effects-and-transitions-using-keyframes/about-keyframes.html) | Definition and controls | Our numeric animation recipe is original, not a creator preset |
| [Frame Hold](https://helpx.adobe.com/ph_en/premiere/desktop/edit-projects/change-clip-speed/freeze-a-video-frame-for-the-duration-of-a-clip.html), [Time Remapping](https://helpx.adobe.com/uk/premiere/desktop/organize-media/file-organization/freeze-a-frame-for-a-portion-of-a-clip-using-time-remapping.html) | Current hold procedures | Interface/layout can change |
| [Essential Sound](https://helpx.adobe.com/uk/premiere/desktop/add-audio-effects/adjust-volume-and-levels/audio-editing-with-essential-sound-panel.html), [Auto-Match](https://helpx.adobe.com/in/premiere/desktop/add-audio-effects/adjust-volume-and-levels/auto-match-audio-loudness.html), [ducking](https://helpx.adobe.com/premiere/desktop/add-audio-effects/adjust-volume-and-levels/automatically-duck-audio.html) | Relevant dialogue and music controls | No universal YouTube loudness target implied |
| [OBS Quick Start](https://obsproject.com/kb/quick-start-guide), [Hybrid MP4](https://obsproject.com/kb/hybrid-mp4) | Sources, testing and container guidance | Learner must test recording/import compatibility |
| [Shure MV6](https://www.shure.com/en-US/products/microphones/mv6), [announcement](https://www.shure.com/en-US/newsroom/shure-introduces-next-generation-of-the-mv6-usb-gaming-microphone) | Current Gen 2 page and dated price | Not Jeff's verified microphone; no sound test performed |
| [FIFINE AM8](https://fifinemicrophone.com/collections/all-fifine-products/products/fifine-am8-microphone-official) | Product features, displayed price and stock notice | Inventory uncertain; no comparative quality test |
| [ATR2100x-USB](https://www.audio-technica.com/en-us/atr2100x-usb) | Discontinued label | Excluded from default new-purchase recommendation |
| [Shure microphone education](https://www.shure.com/en-US/docs/education/Microphone-Techniques-for-Recording) | Relevant placement principles | Exact distance depends on microphone and voice |
| [YouTube encoding](https://support.google.com/youtube/answer/1722171), [Audio Library](https://support.google.com/youtube/answer/3376882) | Current export reference and track attribution conditions | Check actual track rights and actual export |

No creator transcripts, video footage, screenshots, music, logos or branded animations are included in the package. The browser observations informed short original descriptions. The demonstration, animatic and code are original. The only bundled third-party implementation is the MIT-licensed Marked 17.0.5 parser used for rebuilding the reader, with its full license retained.


[Back to contents](#contents)
